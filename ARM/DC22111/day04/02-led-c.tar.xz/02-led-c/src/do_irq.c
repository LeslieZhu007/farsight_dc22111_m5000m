extern void printf(const char *fmt, ...);
unsigned int i = 0;
void do_irq(void) 
{
}
